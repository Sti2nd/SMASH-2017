<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/smashlogo.png">

<title>SMASH</title>

<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-social.css">
<link rel="stylesheet" type="text/css" href="lib/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="lib/custom.css">

    </head>

    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">SMASH</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SMASH 2017 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="om_dette_smash.php">Om SMASH 2017</a></li>
                    <li><a href="program.php">Program</a></li>
                    <li><a href="fellesmusikk.php">Fellesmusikk</a></li>
                    <li><a href="praktisk_info.php">Praktisk info</a></li>
                    <li><a href="statistikk.php">Statistikk</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Historie<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="kort_om_smash.php">Om SMASH</a></li>
                    <li><a href="1960tallet.php">1960-tallet</a></li>
                    <li><a href="1970tallet.php">1970-tallet</a></li>
                    <li><a href="1980tallet.php">1980-tallet</a></li>
                    <li><a href="1990tallet.php">1990-tallet</a></li>
                    <li><a href="2000tallet.php">2000-tallet</a></li>
                    <li><a href="2010tallet.php">2010-tallet</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bilder<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="bilder_buttons.php">Buttons</a></li>
                    <li><a href="bilder_fellesbilder.php">Fellesbilder</a></li>
                </ul>
            </li>
            <li><a href="orchesterdex.php">Orchesterdex</a></li>
            <li><a href="styret.php">Styret</a></li>
            <li><a href="faqs.php">FAQs</a></li>
            <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
</nav>
    <center>
            <div class="container">
                <h1>1980-tallet</h1>
                <br>
            </div>
            <div class="container" style="text-align: left">
                <dt>Vår 1983: Kristiansand</dt>
                <dd>
                    Fra den 11. mars til 13. mars var det SMASH i Kristiansand. Det var innkvartering på Katta. Lørdag ble man vekket av fanfare, og ikke lenge etterpå fulgte det champagne. 
                    På formiddagen var det parade gjennom Kristiansands gater, noe som ble tatt opp på video og senere vist på psildefrokosten. Det ble holdt konsert på Fønix. <br>
                    På kvelden var det fest på Vindmøllen. NHABU ble stiftet, og det ble dermed sikret at SMASH også arrangeres i fremtiden. Det deltok 9 studentorkestre, 
                    et kjempearrangement i datidens målestokk.
                </dd>
                <br>
                <dd>
                    Deltagende orkestre:
                </dd>
                <ul>
                    <li>Strindens Promenade Orchester</li>
                    <li>Biørneblæs</li>
                    <li>Spadser & Blæse-Ensembelet</li>
                    <li>Direksjonsmusikken</li>
                    <li>5 andre</li>
                </ul>
                <br>
                <dd>
                    I Strindens "Men of Might" finnes en sangtekst som ble lagd i samarbeid med Biørneblæs:
                </dd>
                <br>
                <dd><i>
                    Putta på en pils, mel: "Puttin' on a Ritz"
                </i></dd>
                <br>
                <dd><i>
                    Var på SMASH i Kristiansand<br>
                    I mars en gang<br>
                    Vi drakk og sang<br>
                    med sterk aksent<br>
                    Pjalla lite grann
                </i></dd>
                <br>
                <dd><i>
                    Kuppa hvert et <br>
                    band i hele byen<br>
                    kjørte på med <br>
                    RITZ'en på menyen<br>
                    til morgengryen.
                </i></dd>
                <br>
                <dd><i>
                    Biørneblæs og Strindensfolk<br>
                    sang uten tolk<br>
                    når alle folk<br>
                    fikk se at vi<br>
                    putta på en pils. 

                </i></dd>
            </div>
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Vår 1985: Kristiansand</dt>
                <dd>
                    Det ble holdt et SMASH i Kristiansand.
                </dd>
                <br>
                <dd>
                    Deltagende orkeste:
                </dd>
                <ul>
                    <li>Direksjonsmusikken</li>
                    <li>Spadser et Blæse-Ensembelet</li>
                </ul>
            </div>
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høst 1986: Bergen</dt>
                <dd>
                    Det ble holdt et kjempe-SMASH i Bergen. Her ble det innført fanemil.
                </dd>
            </div>
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Vår 1987: Kristiansand</dt>
                <dd>
                    Fra den 27. februar til 1. mars var 14 orkestre på SMASH i Kristiansand. Det ryktes om at det var kaldt. Man så på revyen "Eplet faller ikke – langt ifra". 
                    På lørdagen hadde alle orkestrene konsert på Torvet. Målet var å vekke uteliggerne og å skremme vekk måkene, men kvelden og vinden blåste mer enn dem bort. 
                    Pub til pub-runde fristet mer!<br>
                    På kvelden var det fest på Christianholm festning, og nachspielet, som ble holdt på "Blæserommet", varte til langt ut i de lyse morgentimer.
                </dd>
                <br>
                <dd>
                    Deltagende orkestre:
                </dd>
                <ul>
                    <li>Strindens Promenade Orchester</li>
                    <li>Biørneblæs</li>
                    <li>Spadser & Blæse-Ensembelet</li>
                    <li>Direksjonsmusikken</li>
                    <li>10 andre</li>
                </ul>
            </div>
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høst 1989: Trondheim</dt>
                <dd>
                    Den 10. til 12. november deltok i alt 13 studentorkestre og 300 deltagere på SMASH i Trondheim. Arrangører var Strindens og Berseblæsten. 
                    På lørdag kveld var det fest på Prinsen. På søndag var det båttur og revy.
                </dd>
                <br>
                <dd>
                    Deltagende orkestre:
                </dd>
                <ul>
                    <li>Berseblæsten</li>
                    <li>Strindens Promenade Orchester</li>
                    <li>Direksjonsmusikken</li>
                    <li>10 andre</li>
                </ul>
            </div>
            <br><br>
    </center>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>