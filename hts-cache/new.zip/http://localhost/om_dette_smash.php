<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/smashlogo.png">

<title>SMASH</title>

<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-social.css">
<link rel="stylesheet" type="text/css" href="lib/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="lib/custom.css">

    </head>

    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">SMASH</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SMASH 2017 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="om_dette_smash.php">Om SMASH 2017</a></li>
                    <li><a href="program.php">Program</a></li>
                    <li><a href="fellesmusikk.php">Fellesmusikk</a></li>
                    <li><a href="praktisk_info.php">Praktisk info</a></li>
                    <li><a href="statistikk.php">Statistikk</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Historie<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="kort_om_smash.php">Om SMASH</a></li>
                    <li><a href="1960tallet.php">1960-tallet</a></li>
                    <li><a href="1970tallet.php">1970-tallet</a></li>
                    <li><a href="1980tallet.php">1980-tallet</a></li>
                    <li><a href="1990tallet.php">1990-tallet</a></li>
                    <li><a href="2000tallet.php">2000-tallet</a></li>
                    <li><a href="2010tallet.php">2010-tallet</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bilder<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="bilder_buttons.php">Buttons</a></li>
                    <li><a href="bilder_fellesbilder.php">Fellesbilder</a></li>
                </ul>
            </li>
            <li><a href="orchesterdex.php">Orchesterdex</a></li>
            <li><a href="styret.php">Styret</a></li>
            <li><a href="faqs.php">FAQs</a></li>
            <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
</nav>

            <center>
            <div class="container">
                <h1>SMASH 2017</h1>
                <br>
            </div>
            <div class="container" style="text-align: center">
                <p>
                SMASH 2017 vil bli arrangert i Trondheim fra <b>22 til 24 september</b>. Det blir som alltid en knakende god fest! Vi kan love dere fine opplevelser og 
                nye venner, så sett av helgen og bli med! Det bli morro, det blir liv, det blir alle de kjente og kjære tradisjonene, dette blir kanskje den besteste helga 
                du har vært med på noen gang! Så sett av helgen og bli med på SMASH!
                </p>
                <p>
                Påmeldingen skjer ved at du fyller ut denne påmeldingen: <a href="https://goo.gl/forms/K9hW61VyvpCnXwmz1">Påmelding SMASH 2017</a>. NB: Påmeldingen er bindende.
                <b>Påmeldingsfristen er 1. september</b>.
                </p>
                <p>
                Prisen for å være med på SMASH er <b>kr 400,- per person</b>. Det er samme pris for de som kommer utenbys og de som kommer fra Trondheim. 
                Betalingen skjer ved at hvert orkester betaler <b>en samlet betaling</b> for alle de påmeldte. Du betaler altså inn til ditt studentorchester, som igjen
                betaler Trondheim SMASH innen betalingsfristen <b>8. september.</b> Den samlede betalingen fra orchesteret settes inn på konto: <b>1503.73.01148.</b> Merk 
                gjerne betalingen med navnet på orchesteret.
                </p>
                <p>
                Skulle du ha noen spørmål, se om de har blitt besvart i <a href="faqs.php">FAQ</a>. Hvis ikke, send en epost til <a href="kontakt.php">oss</a>!    
                </p>
                <br/>
                <h3>TLDR;</h3>
                <p>
                <b>Sted og tid:</b> Trondheim, 22. til 24. september <br/>
                <b>Påmelding og frist:</b> <a href="https://goo.gl/forms/K9hW61VyvpCnXwmz1">Påmeldingslink</a>, frist 1.september <br/>
                <b>Pris:</b> 400kr per person (til ditt studentorchester)<br/>
                <small><b>Betalingsfrist:</b> 8. september (for ditt orchester å betale oss)<small>
                </p>
            </div>
            </center>



    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>