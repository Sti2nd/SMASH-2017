<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/smashlogo.png">

<title>SMASH</title>

<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-social.css">
<link rel="stylesheet" type="text/css" href="lib/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="lib/custom.css">

    </head>

    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">SMASH</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SMASH 2017 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="om_dette_smash.php">Om SMASH 2017</a></li>
                    <li><a href="program.php">Program</a></li>
                    <li><a href="fellesmusikk.php">Fellesmusikk</a></li>
                    <li><a href="praktisk_info.php">Praktisk info</a></li>
                    <li><a href="statistikk.php">Statistikk</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Historie<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="kort_om_smash.php">Om SMASH</a></li>
                    <li><a href="1960tallet.php">1960-tallet</a></li>
                    <li><a href="1970tallet.php">1970-tallet</a></li>
                    <li><a href="1980tallet.php">1980-tallet</a></li>
                    <li><a href="1990tallet.php">1990-tallet</a></li>
                    <li><a href="2000tallet.php">2000-tallet</a></li>
                    <li><a href="2010tallet.php">2010-tallet</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bilder<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="bilder_buttons.php">Buttons</a></li>
                    <li><a href="bilder_fellesbilder.php">Fellesbilder</a></li>
                </ul>
            </li>
            <li><a href="orchesterdex.php">Orchesterdex</a></li>
            <li><a href="styret.php">Styret</a></li>
            <li><a href="faqs.php">FAQs</a></li>
            <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
</nav>
        <div class="jumbotron">
            <center>
            <div class="container">
                <h1>SMASH</h1>
                <h2><i>Societé Musicae Academique de Schlaag et Hoorn</i></h2>
                <h3>Ta på skinnvesten, finn frem bartevoksen og bli med!</h3>
                <br> 
                <img class="img-square" src="img/smashlogo.png" alt="Generic placeholder image" style="width: 140px; height: 140px;">
                <br>
                <br>
                <p>Bli med på SMASH 2017 i Trondheim!</p>
                <p>22 - 24 September 2017</p>
                <p>Finn oss på facebook: &nbsp;
                <a class="btn btn-social-icon btn-facebook" href="https://www.facebook.com/events/1335502069858898/" role="button" target="_blank">
                    <i class="fa fa-facebook"></i></a></p>
                <!-- <h2>Antall påmeldte: 294</h2> -->
            </div>
            </center>
        </div>

        <center>
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <img class="img-square" src="img/info.png" alt="Generic placeholder image" style="width: 140px; height: 140px;">
                    <h2>SMASH 2017</h2>
                    <p>Informasjon om SMASH 2017</p>
                    <p><a class="btn btn-default" href="om_dette_smash.php" role="button">Les mer &raquo;</a></p>
                </div>
                <div class="col-lg-4">
                    <img class="img-square" src="img/program.png" alt="Generic placeholder image" style="width: 140px; height: 140px;">
                    <h2>Program</h2>
                    <p>Program for SMASH 2017 </p>
                    <p><a class="btn btn-default" href="program.php" role="button">Les mer &raquo;</a></p>
                </div>
                <div class="col-lg-4">
                    <img class="img-square" src="img/musikk.jpg" alt="Generic placeholder image" style="width: 186px; height: 140px;">
                    <h2>Fellesmusikk</h2>
                    <p>Fellesmusikk for SMASH 2017</p>
                    <p><a class="btn btn-default" href="fellesmusikk.php" role="button">Les mer &raquo;</a></p>
                </div>
            </div>
        </div>
        </center>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>

</html>