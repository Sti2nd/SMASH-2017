<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/smashlogo.png">

<title>SMASH</title>

<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-social.css">
<link rel="stylesheet" type="text/css" href="lib/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="lib/custom.css">

    </head>
    
    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">SMASH</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SMASH 2017 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="om_dette_smash.php">Om SMASH 2017</a></li>
                    <li><a href="program.php">Program</a></li>
                    <li><a href="fellesmusikk.php">Fellesmusikk</a></li>
                    <li><a href="praktisk_info.php">Praktisk info</a></li>
                    <li><a href="statistikk.php">Statistikk</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Historie<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="kort_om_smash.php">Om SMASH</a></li>
                    <li><a href="1960tallet.php">1960-tallet</a></li>
                    <li><a href="1970tallet.php">1970-tallet</a></li>
                    <li><a href="1980tallet.php">1980-tallet</a></li>
                    <li><a href="1990tallet.php">1990-tallet</a></li>
                    <li><a href="2000tallet.php">2000-tallet</a></li>
                    <li><a href="2010tallet.php">2010-tallet</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bilder<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="bilder_buttons.php">Buttons</a></li>
                    <li><a href="bilder_fellesbilder.php">Fellesbilder</a></li>
                </ul>
            </li>
            <li><a href="orchesterdex.php">Orchesterdex</a></li>
            <li><a href="styret.php">Styret</a></li>
            <li><a href="faqs.php">FAQs</a></li>
            <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
</nav>
            
            <center>
            <div class='container row'>
                <img class="img-responsive center-block" src="img/orchesterdex/Whos_that_Pokemon2.png" 
                alt="Who's that Studentorchester'">
                <!-- There is a fine mixture of bootstrap and flexbox which makes this page work. The following row-eq-height class makes
                use of flexbox to get equal height of the cards in the same row. -->
                <div class='row-eq-height'>

                
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/colorless.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Berseblæsten</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1953</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/colorless-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/berg.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/berg.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Urnorsk</b>. <b>Naturlig habitat: </b>Gløshaugen, Trondheim</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Hardbarka bergsmenn som alltid vinner nasjet. Sanger blir sunget titt og ofte og er som regel hundre år gamle.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Svart ulluniform med tinnknapper og tilhørende svart hatt. Ullstrømpene er hjemmestrikket og skinnet bæres foran eller bak.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Berseblæsten, drikk!</p>
                                    <p class='card-text'><big><b>Type: </b></big>Stein og olje</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/water.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Student&shy;orchesteret Biørneblæs</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1971</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/water-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/biorneblaes.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/biorneblaes.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>The one and only</b>. <b>Naturlig habitat: </b>Blindern, Oslo</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Tanta til Beate, Tanta til Beate, Tanta til Beate. På mirakuløst vis kommer de på sisteplass i hver phanemiil. Favorittsangen er Tanta Til Beate.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Grønn bukse, gul skjorte, sort jakke, sort hatt og grønn sløyfe</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Biørneblæs skåler generelt alt for lite!</p>
                                    <p class='card-text'><big><b>Type: </b></big>Realist</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/psychic.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Corpsus Juris</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1963</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/psychic-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/corpsus.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/corpsus.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Mellom linjene</b>. <b>Naturlig habitat: </b>Det juridiske fakultet, Oslo</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Maskot: Corpsusgutten?</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Svart kappe og hvit parykk</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Ukjent. (Forslag: Skål in dubio pro reo (Skål til det motsatte er bevist)!)</p>
                                    <p class='card-text'><big><b>Type: </b></big>Jus</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/fire_classic.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Student&shy;orchesteret Dei Taktlause</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1990</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/fire-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/taktlaus.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/taktlaus.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Utforskande</b>. <b>Naturlig habitat: </b>Gløshaugen, Trondheim</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Raringane ifrå Trøndelag som er overalt, til og med bak deg nå! Dei Taktlause spelar høglydt i alle moglege taktartar. Favorittsongen er Time Warp.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Halvferdig klovnedrakt? Legenda seier at nokre videregående elevar fikk i oppdrag å sy uniforma, og dei blei perfekt! Rar hatt er ein del av uniforma.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Dei Taktlause skåler generelt, sjø!</p>
                                    <p class='card-text'><big><b>Type: </b></big>Elektrisk</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/grass.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Dragern</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1998</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/grass-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/dragern.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/dragern.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>HMS først!</b>. <b>Naturlig habitat: </b>Gløshaugen, Trondheim</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Tiltrekkes av anleggsmaskiner og veiskilt. Muligens mechanophile og har øl i blodet. Favorittsangen er Byggmester Bob.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Oransje refleksvest og bukse i Statens Vegvesen-stil. Og selvfølgelig anleggshjelm!</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Kan det skåles? Klart det kan!</p>
                                    <p class='card-text'><big><b>Type: </b></big>Byggmester</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/lightning.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Force Marsjør Juzz-Band & Fotnotene</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1979</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/lightning-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/force.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/force.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Større krefter</b>. <b>Naturlig habitat: </b>Det juridiske fakultet, Bergen</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Livlige musikanter med skarre-r som elsker Hansa.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Dommerkapper, hvit parykk, skjorte og sløyfe i valgfri farge</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big><sub>Skå</sub>åå<sup>ål</sup></p>
                                    <p class='card-text'><big><b>Type: </b></big>Jus</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/colorless.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Medicinsk Blæse- et Spadser&shy;ensemble</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1963</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/colorless-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/med_spadser.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/med_spadser.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Lenge leve, lenge blæse!</b>. <b>Naturlig habitat: </b>Universitet i Bergen</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Medicinere med phete laater. So Happy!</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Hvit skjorte og sløyfe, svart bukse og jakke, og bowlerhatt som holder på vettet.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Ukjent</p>
                                    <p class='card-text'><big><b>Type: </b></big>Doktor</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/water.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Medicinsk Selskabs Orchester</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1993</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/water-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/med-selskab.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/med-selskab.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Undercover pirates &#9760</b>. <b>Naturlig habitat: </b>St. Olavs, Nidaros</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Practphulde exemphlarer af arten Musicant. De medicinsk skolerede Horders høiculturelle Midtpunkt.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Grønne strømper, (hansker) og sløyfe, hatt med grønt bånd (og grønt skjerf), svarte jakker, bukser og skjorter.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Ukjent</p>
                                    <p class='card-text'><big><b>Type: </b></big>Doktor</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/psychic.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Medicinsk Paradeorchæster</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1961</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/psychic-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/med-parade.gif' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/med-parade.gif' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Ærede Phæns!</b>. <b>Naturlig habitat: </b>Oslo</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Eders Protector Minor Orchæstris er H.M. Kongen Harald V. Et noglet ambivalent forhold til ridende Politi til Hæst et gaaende Gardechef til fots.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Sort Sjakett/Livkjole/Bonjourfrakk med tilhørende Bukser et Vest samt hvit Skjorte, Studenterlue et Sløyfe i Valgphri Pharge</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Ingen. Vi skaaler dog naar vi vil, hvor vi vil et saa lenge vi vil.</p>
                                    <p class='card-text'><big><b>Type: </b></big>Doktor</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/fire_classic.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Musik&shy;selskabet Larmonien</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1966</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/fire-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/larmonien.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/larmonien.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Inimicissima musicae</b>. <b>Naturlig habitat: </b>Universitet i Bergen</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Røde musikanter med lange og klassiske tradisjoner. Maskot: Hans Høyhet Nygaardsgubben, et 300 år gammelt troll.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Svarte sko, bukser og studenterlue. Hvite skjorter og en rød sjakettjakke.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Ukjent</p>
                                    <p class='card-text'><big><b>Type: </b></big>Mytisk</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/grass.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Ompagniet</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1984</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/grass-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/ompagniet.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/ompagniet.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Værdens nordligste studentblaaseorchæster</b>. <b>Naturlig habitat: </b>Universitet i Tromsø</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Ompagneurer trosser all slags vær for å lage lyd for folk og reinsdyr. Bading gjøres helst i fontener.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Svart bukse, svart snippfrakk, hvit skjorte og maksimalt stygt slips</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Se i taket!</p>
                                    <p class='card-text'><big><b>Type: </b></big>Isbjørn</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/lightning.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Spadser et Blæse-Ensembelet</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1974</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/lightning-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/bibel_spadser.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/bibel_spadser.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>For vi er de beste, jum jum</b>. <b>Naturlig habitat: </b>Kristiandsand</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Glade solbrune sørlendinger med hengivenhet til Kongen. Favorittsangen er Langemanns sang.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Svart jakke, bukser og bowlerhatt. Hvit skjorte og sløyfe, rødt magebånd.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Armen i vinkel, en-to-tre-fir pelikan, weoweoweo, skål!</p>
                                    <p class='card-text'><big><b>Type: </b></big>Sjørøver</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/colorless.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Strindens Promenade Orchester</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1963</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/colorless-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/strindens.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/strindens.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Tigergutt <3</b>. <b>Naturlig habitat: </b>Samfundet, Trondheim</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Dixiejazzsambaswing-elskende studenter, med show, og uten noter. Favorittsangen er The Stars and Stripes Forever</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Blå og hvit stripete genser, svart vest eller jakke, og grå bukse</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Ukjent</p>
                                    <p class='card-text'><big><b>Type: </b></big>Dixie biscuit</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/water.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>TapHel & Toddy</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1967</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/water-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/taphel.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/taphel.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Stoff er digg å holde på med!</b>. <b>Naturlig habitat: </b>Gløshaugen, Trondheim</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Gale kjemikere av beste sorten. Har slemmetoddy på termos og festLF skriblet på labfrakken. Favorittsangen er Just a Gigolo.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Labfrakk og burgunderrød berret</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Ukjent</p>
                                    <p class='card-text'><big><b>Type: </b></big>Kjemisk</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Code for one card -->
                    <div class='col-md-6'>
                        <!-- Get 'random' card background in php -->
                        <div class='card-line' style='background-image: url(img/orchesterdex/psychic.png); background-size: cover;'>
                            <div class='card'>
                                <div style='text-align: left'>
                                    <div class='card-title-container'>
                                        <h3 class='card-title'>Åsblæsten</h3>
                                    </div>
                                    <div class='red-number-container'>
                                        <h3 class='red-number'>1974</h3>
                                        <!-- Get 'random' card icon in php. Same color / matches card background. -->
                                        <img class='img-responsive card-icon' src='img/orchesterdex/psychic-icon.png' alt='Card icon'>
                                    </div>
                                    <!-- Get card image based on the student orchestra name -->
                                    <a href='img/orchesterdex/aasblaesten.jpg' target='_blank'><img class='img-responsive card-img-top' 
                                    src='img/orchesterdex/aasblaesten.jpg' alt='Orchestra specimen'></a>
                                    <div class='card-banner'>
                                        <p class='card-text'><b>Gråtass FTW!</b>. <b>Naturlig habitat: </b>Ås</p>
                                    </div>
                                    <p class='card-text'><big><b>Kjennetegn: </b></big>Den orginale Åsblæstern er sjølberga med åkre, kyr og mekanisk pløyeinnretning. Maskot: Hans Harald, den kongelige panda. Favorittsangen er Surfbrett</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Uniform: </b></big>Rød busserull med hvite striper, strømper og hatt.</p>
                                    <hr class='black-divider'>
                                    <p class='card-text'><big><b>Skål: </b></big>Generelt! Det skåles alt for lite!</p>
                                    <p class='card-text'><big><b>Type: </b></big>Jord</p>
                                </div>
                            </div>
                        </div>
                    </div>
                                    </div>
            </div>
            <br/><br/>
            <p>For tilgang på bedre/original oppløsning av bildene på kortene, gå til Foto og video-arkiv mappen og så orchesterdex-mappen
                 på Google Drive eller spør 
                <a href="https://www.facebook.com/groups/1496116444049224/" target="_blank">NASH</a> om tilgang.</p>
            </center>
    

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>
