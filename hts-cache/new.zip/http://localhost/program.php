<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/smashlogo.png">

<title>SMASH</title>

<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-social.css">
<link rel="stylesheet" type="text/css" href="lib/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="lib/custom.css">

    </head>
    
    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">SMASH</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SMASH 2017 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="om_dette_smash.php">Om SMASH 2017</a></li>
                    <li><a href="program.php">Program</a></li>
                    <li><a href="fellesmusikk.php">Fellesmusikk</a></li>
                    <li><a href="praktisk_info.php">Praktisk info</a></li>
                    <li><a href="statistikk.php">Statistikk</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Historie<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="kort_om_smash.php">Om SMASH</a></li>
                    <li><a href="1960tallet.php">1960-tallet</a></li>
                    <li><a href="1970tallet.php">1970-tallet</a></li>
                    <li><a href="1980tallet.php">1980-tallet</a></li>
                    <li><a href="1990tallet.php">1990-tallet</a></li>
                    <li><a href="2000tallet.php">2000-tallet</a></li>
                    <li><a href="2010tallet.php">2010-tallet</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bilder<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="bilder_buttons.php">Buttons</a></li>
                    <li><a href="bilder_fellesbilder.php">Fellesbilder</a></li>
                </ul>
            </li>
            <li><a href="orchesterdex.php">Orchesterdex</a></li>
            <li><a href="styret.php">Styret</a></li>
            <li><a href="faqs.php">FAQs</a></li>
            <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
</nav>

        <center>
        <div class="container">
            <br>
            <p> Årets program kommer i ukene før SMASH </p>
            <!--
            <h1>Program</h1>
            <p>(Klikk på linkene for å komme til Google Maps)</p>
            <br>
        </div>-->
        </center>
<!--
        <center>
        <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <h3>Fredag</h3>
                    </div>
                    <div class="col-md-6 col-md-offset-3"> 
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Aktivitet</th>
                                    <th>Hvor</th>
                                    <th>Klokkeslett</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>Ankomst</th>
                                    <td>Trondheim</td>
                                    <td>- 18:00</td>
                                </tr>
                                <tr>
                                    <th>Åpning Frimurerlogen</th>
                                    <td><a href="https://www.google.no/maps/place/Frimurerlogen/@63.43009,10.399743,14z/data=!4m2!3m1!1s0x466d319bd29d55b3:0xe0e4e3fdf8991cd1?hl=en" 
                                        target="_blank">Frimurerlogen</a></td>
                                    <td>18:00</td>
                                </tr>
                                <tr>
                                    <th>Middag og<br>Spritorientering</th>
                                    <td>
                                        <a href="https://www.google.no/maps/place/Frimurerlogen/@63.43009,10.399743,14z/data=!4m2!3m1!1s0x466d319bd29d55b3:0xe0e4e3fdf8991cd1?hl=en" 
                                        target="_blank">Frimurerlogen</a><br>
                                        <a href="https://www.google.no/maps/place/Marinen,+7013+Trondheim/@63.4253743,10.3947041,16z/data=!4m7!1m4!3m3!1s0x466d3190d0a9777d:0xbca686c9e685aa21!2sMarinen,+7013+Trondheim!3b1!3m1!1s0x466d3190d0a9777d:0xbca686c9e685aa21"
                                        target="_blank">Marinen</a>
                                    </td>
                                    <td>19:00 - 22:00</td>
                                </tr>
                                <tr>
                                    <th>Fest</th>
                                    <td><a href="https://www.google.no/maps/place/Frimurerlogen/@63.43009,10.399743,14z/data=!4m2!3m1!1s0x466d319bd29d55b3:0xe0e4e3fdf8991cd1?hl=en" 
                                    target="_blank">Frimurerlogen</a></td></td>
                                    <td>22:00 - 02:00</td>
                                </tr>
                                <tr>
                                    <th>Buss til skolene<br>for overnatting</th>
                                    <td>
                                        <a href="https://www.google.no/maps/place/%C3%85svang+skole/@63.4207494,10.427979,14z/data=!4m2!3m1!1s0x466d304a789417e7:0xe1258e29e0e00eba"
                                        target="_blank">Åsvang Skole</a>
                                        <br>
                                        <a href="https://www.google.no/maps/place/Lade+skole/@63.4303561,10.4159104,14z/data=!4m2!3m1!1s0x466d310fcf4c454d:0x9444215d155bb034"
                                        target="_blank">Lade Skole</a>
                                    </td>
                                    <td>02:30</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <h3>Lørdag</h3>
                    </div>
                    <div class="col-md-6 col-md-offset-3">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Aktivitet</th>
                                    <th>Hvor</th>
                                    <th>Klokkeslett</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>Frokost</th>
                                    <td><a href="https://www.google.no/maps/place/Varmeteknisk,+7034+Trondheim/@63.4188774,10.4041653,17z/data=!3m1!4b1!4m2!3m1!1s0x466d3195913cb995:0x283af12c08fdd21"
                                    target="_blank">Kantine Kjelhuset NTNU</a></td>
                                    <td>09:00 - 10:30</td>
                                </tr>
                                <tr>
                                    <th>Phanemil</th>
                                    <td><a href="https://www.google.no/maps/place/H%C3%B8yskoleparken,+7030+Trondheim/@63.4213933,10.3967979,16z/data=!4m2!3m1!1s0x466d3194002ea7df:0x8d938e93695eff10"
                                    target="_blank">Høyskoleparken</a></td>
                                    <td>11:00 - 12:00</td>
                                </tr>
                                <tr>
                                    <th>Internkonsert</th>
                                    <td><a href="https://www.google.no/maps/place/H%C3%B8yskoleparken,+7030+Trondheim/@63.4213933,10.3967979,16z/data=!4m2!3m1!1s0x466d3194002ea7df:0x8d938e93695eff10"
                                    target="_blank">Høyskoleparken</a></td>
                                    <td>12:00 - 14:00</td>
                                </tr>
                                <tr>
                                    <th>Pub til pub</th>
                                    <td>Sentrum</td>
                                    <td>14:00 - 15:45</td>
                                </tr>
                                <tr>
                                    <th>UKErevy</th>
                                    <td><a href="https://www.google.no/maps/place/Studentersamfundet+i+Trondheim/@63.4224317,10.3954509,14z/data=!4m2!3m1!1s0x466d319143981307:0xb5338a2acc49470f?hl=en" target="_blank">Studentersamfundet</a></td>
                                    <td>17:00 - 20:00</td>
                                </tr>
                                <tr>
                                    <th>Åpning Frimurerlogen</th>
                                    <td><a href="https://www.google.no/maps/place/Frimurerlogen/@63.43009,10.399743,14z/data=!4m2!3m1!1s0x466d319bd29d55b3:0xe0e4e3fdf8991cd1?hl=en" 
                                        target="_blank">Frimurerlogen</a></td>
                                    <td>18:00</td>
                                </tr>
                                <tr>
                                    <th>Middag og fest</th>
                                    <td><a href="https://www.google.no/maps/place/Frimurerlogen/@63.43009,10.399743,14z/data=!4m2!3m1!1s0x466d319bd29d55b3:0xe0e4e3fdf8991cd1?hl=en" 
                                    target="_blank">Frimurerlogen</a></td></td>
                                    <td>20:00 - 02:00</td>
                                </tr>
                                <tr>
                                    <th>Buss til skolene<br>for overnatting</th>
                                    <td>
                                        <a href="https://www.google.no/maps/place/%C3%85svang+skole/@63.4207494,10.427979,14z/data=!4m2!3m1!1s0x466d304a789417e7:0xe1258e29e0e00eba"
                                        target="_blank">Åsvang Skole</a>
                                        <br>
                                        <a href="https://www.google.no/maps/place/Lade+skole/@63.4303561,10.4159104,14z/data=!4m2!3m1!1s0x466d310fcf4c454d:0x9444215d155bb034"
                                        target="_blank">Lade Skole</a>
                                    </td>
                                    <td>02:30</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <h3>Søndag</h3>
                    </div>
                    <div class="col-md-6 col-md-offset-3">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Aktivitet</th>
                                    <th>Hvor</th>
                                    <th>Klokkeslett</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th>Psildefrokost</th>
                                    <td><a href="https://www.google.no/maps/place/Varmeteknisk,+7034+Trondheim/@63.4188774,10.4041653,17z/data=!3m1!4b1!4m2!3m1!1s0x466d3195913cb995:0x283af12c08fdd21"
                                    target="_blank">Kantine Kjelhuset NTNU</a></td>
                                    <td>09:00 - 12:00</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                </div>
        </div>
        </center>   
-->

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>