<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/smashlogo.png">

<title>SMASH</title>

<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-social.css">
<link rel="stylesheet" type="text/css" href="lib/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="lib/custom.css">

    </head>

    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">SMASH</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SMASH 2017 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="om_dette_smash.php">Om SMASH 2017</a></li>
                    <li><a href="program.php">Program</a></li>
                    <li><a href="fellesmusikk.php">Fellesmusikk</a></li>
                    <li><a href="praktisk_info.php">Praktisk info</a></li>
                    <li><a href="statistikk.php">Statistikk</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Historie<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="kort_om_smash.php">Om SMASH</a></li>
                    <li><a href="1960tallet.php">1960-tallet</a></li>
                    <li><a href="1970tallet.php">1970-tallet</a></li>
                    <li><a href="1980tallet.php">1980-tallet</a></li>
                    <li><a href="1990tallet.php">1990-tallet</a></li>
                    <li><a href="2000tallet.php">2000-tallet</a></li>
                    <li><a href="2010tallet.php">2010-tallet</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bilder<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="bilder_buttons.php">Buttons</a></li>
                    <li><a href="bilder_fellesbilder.php">Fellesbilder</a></li>
                </ul>
            </li>
            <li><a href="orchesterdex.php">Orchesterdex</a></li>
            <li><a href="styret.php">Styret</a></li>
            <li><a href="faqs.php">FAQs</a></li>
            <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
</nav>
            <center>
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <h1>Fellesmusikk</h1>
                        <hr>
                        <h2>Fellesnummer</h2>
                        <p>Fellesnummeret vil komme kort tid etter sommeren.</p>
                        <h2>Ofte spilte sanger</h2>
                        <br>
                    </div>
                    <div class="col-md-6 col-md-offset-3"> 
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <td>
                                        <dd><b>- Dixieland Strut</b> (arr. Frank D. Cofield)</dd>
                                        <dd><b>- Bruremarsj</b> (arr. Jon Magne Førde)</dd>
                                        <dd><b>- A swinging safari</b> (arr. Hal Leonard)</dd>
                                        <dd><b>- Olsenbanden</b> (arr. Frode Thingnæs)</dd>
                                        <dd><b>- Happy</b> (arr. Torjusen)</dd>
                                        <dd><b>- Holmenkollmarsjen</b> (arr. Allan Johanson eller Idar Torskangerpoll)</dd>
                                        <dd><b>- The Bare Necessities</b> (arr. Bjørn Morten Kjærnes)</dd>
                                        <dd><b>- Soul Bossa Nova</b> (arr. Per-Olof Ukkonen)</dd>
                                    </td>
                                </tr>
                            </thead>
                        </table>
                        <p>Hvis orkesteret ditt mangler noen av disse send en <a href="kontakt.php">epost</a> eller spør på <a href="https://www.facebook.com/events/1335502069858898/">Facebook</a>.
                    </div>
                </div>
            </div>
            </center>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>