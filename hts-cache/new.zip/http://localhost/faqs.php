<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/smashlogo.png">

<title>SMASH</title>

<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-social.css">
<link rel="stylesheet" type="text/css" href="lib/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="lib/custom.css">

    </head>

    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">SMASH</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SMASH 2017 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="om_dette_smash.php">Om SMASH 2017</a></li>
                    <li><a href="program.php">Program</a></li>
                    <li><a href="fellesmusikk.php">Fellesmusikk</a></li>
                    <li><a href="praktisk_info.php">Praktisk info</a></li>
                    <li><a href="statistikk.php">Statistikk</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Historie<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="kort_om_smash.php">Om SMASH</a></li>
                    <li><a href="1960tallet.php">1960-tallet</a></li>
                    <li><a href="1970tallet.php">1970-tallet</a></li>
                    <li><a href="1980tallet.php">1980-tallet</a></li>
                    <li><a href="1990tallet.php">1990-tallet</a></li>
                    <li><a href="2000tallet.php">2000-tallet</a></li>
                    <li><a href="2010tallet.php">2010-tallet</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bilder<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="bilder_buttons.php">Buttons</a></li>
                    <li><a href="bilder_fellesbilder.php">Fellesbilder</a></li>
                </ul>
            </li>
            <li><a href="orchesterdex.php">Orchesterdex</a></li>
            <li><a href="styret.php">Styret</a></li>
            <li><a href="faqs.php">FAQs</a></li>
            <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
</nav>

            <center>
            <div class="container">
                <h1>Ofte stilte spørsmål</h1><br>
                    <dt>Hvem kan være med på SMASH?</dt>
                    <dd>SMASH er for alle studentorchestre i Norge. Hvis du er fra et studentorkester fra et annet 
                        land eller ikke er tilknyttet noe studentorchester, send en 
                        <a href="kontakt.php">epost</a> og hør om du kan være med.</dd>
                    <br>
                    <dt>Hvordan er standarden på overnatting?</dt>
                    <dd>Av høyeste kvalitet!... hvis du er vant med å spille i korps, og altså sove i gymsaler og 
                        klasserom. Kan også være at man sover hjemme hos studenter i vertskapsbyen.</dd>
                    <br>
                    <dt>Hva må man ha med på SMASH?</dt>
                    <dd>Deltakerne tar med liggeunderlag, sovepose, uniform, instrument, klær, håndkle, såpe og 
                        annet de kan trenge for et helgeopphold i en by. Orchesteret tar med phanen sin, og 
                        tradisjonelt en gave til vertskapet.</dd>
                    <br>

                

            </div>
            </center>


    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>