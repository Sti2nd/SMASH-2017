<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/smashlogo.png">

<title>SMASH</title>

<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-social.css">
<link rel="stylesheet" type="text/css" href="lib/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="lib/custom.css">

    </head>

    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">SMASH</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SMASH 2017 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="om_dette_smash.php">Om SMASH 2017</a></li>
                    <li><a href="program.php">Program</a></li>
                    <li><a href="fellesmusikk.php">Fellesmusikk</a></li>
                    <li><a href="praktisk_info.php">Praktisk info</a></li>
                    <li><a href="statistikk.php">Statistikk</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Historie<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="kort_om_smash.php">Om SMASH</a></li>
                    <li><a href="1960tallet.php">1960-tallet</a></li>
                    <li><a href="1970tallet.php">1970-tallet</a></li>
                    <li><a href="1980tallet.php">1980-tallet</a></li>
                    <li><a href="1990tallet.php">1990-tallet</a></li>
                    <li><a href="2000tallet.php">2000-tallet</a></li>
                    <li><a href="2010tallet.php">2010-tallet</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bilder<span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="bilder_buttons.php">Buttons</a></li>
                    <li><a href="bilder_fellesbilder.php">Fellesbilder</a></li>
                </ul>
            </li>
            <li><a href="orchesterdex.php">Orchesterdex</a></li>
            <li><a href="styret.php">Styret</a></li>
            <li><a href="faqs.php">FAQs</a></li>
            <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </div>
</nav>
    <center>
            <div class="container">
                <h1>2000-tallet</h1>
                <br>
            </div>
            <div class="container" style="text-align: left">
                <dt>Høst 2000: Ås</dt>
                <dd>
                    Den 20. til 22. oktober var det SMASH i Ås. Strindens fikk fiaskoprisen under fanemila, da de styrte trillebåra i feil retning. 
                    På Samfunnet ble revyen "Midt i maneten" vist. Lørdag kveld var det Motorpsycho-konsert, og senere nachspiel i Meierikjelleren. 
                </dd>
                <br>
                <dd>
                    Deltagende orkestre var:
                </dd>
                <ul>
                    <li>Strindens Promenade Orchester</li>
                    <li>Direksjonsmusikken</li>
                    <li>Dei Taktlause (32 stykker)</li>
                    <li>Larmonien</li>
                    <li>Taphel & Toddy (12 stykker)</li>
                    <li>Tåkeluren</li>
                    <li>Åsblæst'n</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Vår 2001: Kristiansand</dt>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høst 2001: Trondheim</dt>
                <dd>
                    2. – 4. november. Fredag kveld var det nachspiel på Duedalen MC. På lørdag var det fanemil, og oppgaven var å hoppe bukk rundt UKA-billettboden. 
                    Været ble dårlig, og konserten på Nordre derfor kort. Deretter var det øl på Naboen og tacomiddag i Hangaren. Senere var det internkonsert i Bakke Bydelshus. 
                    Etterpå var det konsert med "Loose Booty Funkateers". Nachspiel på Duedalen MC.
                </dd>
                <br>
                <dd>
                    Deltagende orkestre:
                </dd>
                <ul>
                    <li>Strindens Promenade Orchester</li>
                    <li>Åsblæst'n</li>
                    <li>Odontoblæsten</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høst 2002: Åslo</dt>
                <dd>
                    25. – 27. oktober var det kombinert SMASH i Ås og Oslo. Det hele startet i Oslo. Fredag natt overnattet man på Hersleb skole. 
                    Klokka 14 dagen etter gikk bussen videre til Ås. Der var det mye pizza og revy.
                </dd>
                <br>
                <dd>
                    Deltagende orkestre:
                </dd>
                <ul>
                    <li>Berseblæsten</li>
                    <li>Biørneblæs</li>
                    <li>Corpsus Juris</li>
                    <li>Dei Taktlause</li>
                    <li>Larmonien</li>
                    <li>Ohmp & Blæds ?</li>
                    <li>Strindens Promenade Orchester</li>
                    <li>Taphel & Toddy</li>
                    <li>Åsblæst'n</li>
                    <li>Tåkeluren</li>
                    <li>Direksjonsmusikken ?</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høst 2003: Trondheim</dt>
                <dd>
                    1. – 3. november ble SMASH avholdt i Trondheim. Deltagende orkestre var:
                </dd>
                <ul>
                    <li>Biørneblæs</li>
                    <li>Dei Taktlause</li>
                    <li>Larmonien</li>
                    <li>Ohmp & Blæds</li>
                    <li>Taphel & Toddy</li>
                    <li>Tåkeluren</li>
                    <li>Åsblæst'n</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Vår 2004: Bergen</dt>
                <dd>
                    16. – 18. april ble det avholdt SMASH i Bergen. Deltagende orkestre var:
                </dd>
                <ul>
                    <li>Biørneblæs</li>
                    <li>Dei Taktlause</li>
                    <li>Force Marsjør Juzz-Band og Fotnotene</li>
                    <li>Larmonien</li>
                    <li>Taphel & Toddy ?</li>
                    <li>Teknolikken</li>
                    <li>Åsblæst'n</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høst 2004: Åslo</dt>
                <dd>
                    22. – 24. oktober. Deltagende orkestre var:
                </dd>
                <ul>
                    <li>Biørneblæs</li>
                    <li>Dei Taktlause (10 stykker)</li>
                    <li>Force Marsjør Juzz-Band og Fotnotene / Corpsus Juris</li>
                    <li>Larmonien</li>
                    <li>Taphel & Toddy</li>
                    <li>Åsblæst'n</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høst 2005: Trondheim</dt>
                <dd>
                    Fra 30. september til 2. oktober var det SMASH i Trondheim. Fredagen besto av fest på Exit i Fjordgata og nachspiel på Duedalen MC. 
                    Lørdagen var det tid for fanemil, og kun to orkestre hadde faktisk fane. Middag var det på Peppes, og så fest på Riggen MC-klubb. 
                </dd>
                <br>
                <dd>
                    Deltagende orkestre:
                </dd>
                <ul>
                    <li>Dei Taktlause</li>
                    <li>Larmonien</li>
                    <li>Strindens Promenade Orchester</li>
                    <li>Taphel & Toddy</li>
                    <li>Tåkeluren</li>
                    <li>Åsblæst'n</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Våren 2006: Bergen</dt>
                <dd>
                    24. – 26. mars. Deltagende orkestre var:
                </dd>
                <ul>
                    <li>Dei Taktlause (6 stykk)</li>
                    <li>Force Marsjør Juzz-Band og Fotnotene</li>
                    <li>Ohmp & Blæds</li>
                    <li>+ Flere</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høsten 2006: Åslo</dt>
                <dd>
                    20. – 22. oktober. Internkonserten blir holdt i kjemi-kantina på Blindern, så videre med toget til Ås. Konsert på Samfunnet. 
                </dd>
                <br>
                <dd>
                    Deltagende orkestre var:
                </dd>
                <ul>
                    <li>Biørneblæs</li>
                    <li>Dei Taktlause (18 stykker)</li>
                    <li>Ohmp & Blæds</li>
                    <li>Taphel & Toddy</li>
                    <li>Åsblæst'n</li>
                    <li>+ Flere</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høsten 2007: Trondheim</dt>
                <dd>
                    28. – 30. september. Overnatting på Singsaker skole. Middag på Peppes, fest på Tiger-tiger, Moholt og Nardo klubbhus. 
                    Fra dette SMASHet finnes det også en rød T-skjorte. 
                </dd>
                <br>
                <dd>
                    Deltagende orkestre var:
                </dd>
                <ul>
                    <li>Berseblæsten</li>
                    <li>Biørneblæs</li>
                    <li>Dei Taktlause (18 stykk)</li>
                    <li>Dragern</li>
                    <li>Larmonien</li>
                    <li>Taphel & Toddy</li>
                    <li>Tåkeluren</li>
                    <li>Åsblæst'n</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Våren 2008: Bergen</dt>
                <dd>
                    Den 28. til 30. mars var det SMASH i Bergen. Deltagende orkestre var:
                </dd>
                <ul>
                    <li>Berseblæsten</li>
                    <li>Dei Taktlause</li>
                    <li>Force Marsjør Juzz-Band og Fotnotene</li>
                    <li>Larmonien</li>
                    <li>Ohmp og Blæds</li>
                    <li>Spadser et Blæse-Ensembelet</li>
                    <li>Teknolikken</li>
                </ul>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høst 2008: Åslo</dt>
            </div> 
            <br><br>
            <div class="container" style="text-align: left">
                <dt>Høst 2009: Trondheim</dt>
                <dd>
                    Holdes 25. – 29. september. Det kom hele 2 orkestre utenbys fra!
                </dd>
            </div> 
            <br><br>
    </center>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
    </body>
</html>